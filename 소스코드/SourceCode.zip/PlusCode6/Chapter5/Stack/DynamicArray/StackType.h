IsEmpty
Push A
Push Z
Push S
Push Q
Top
Pop
Top
Pop
Top
Pop
Top
Pop
Push D
Push E
Push F
Push G
Top
Pop
Top
Pop
Top
Pop
Top
Pop
Push A
Pop
Push L
Push M
Pop
Top
Pop
IsEmpty
Push M
IsEmpty
Pop
IsEmpty
Push S
Push X
Push Y
Push Z
IsFull
Push 1
IsFull
Push Z
Pop
Pop
Pop
Pop
Pop
Pop
Top
Error
Quit



