Files

Recursive Tree
	TreeType.h	Contains the specification for class TreeType
	TreeType.cpp	Contains the implementation for class TreeType
	QueType.h		Contains the specification for class QueType
	QueType.cpp	Contains the implementation for class QueType
	TreeDr.cpp	Test driver for Tree Type
	TypeType.in	Test plan
	

Iterative Tree
	ITreeType.h	Contains the specification for class TreeType
	ITreeType.cpp	Contains the implementation for class TreeType
	QueType.h		Contains the specification for class QueType
	QueType.cpp	Contains the implementation for class QueType
	ITreeDr.cpp	Test driver for Tree Type
	TypeType.in	Test plan
	

Words
	Words.cpp		Unique word generating program
	history.in	Input to word program
	
	

	 		
