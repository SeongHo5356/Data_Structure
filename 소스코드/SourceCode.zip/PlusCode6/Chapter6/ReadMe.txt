Files

Specialized List

	SpecializedList.h		The specification and implementation of
						class SpecializedList
	SpecialDr.cpp			Test driver for class SpecializedList
	Special.in			Input to test driver

	Virtual.cpp			Example of virtual functions

Templated
	StackType.h			Specification and implementation for
						templated stack
	StackDr.cpp			Driver for test of templated stack
	StackType.in			Input for test run of templated stack


Functions from Text (not complete programs)
	LargeInt.h			Specification of class LargeInt functions from
						the chapter
	LargeInt.cpp			Implementation of class LargeInt functions from
						the chapter
	double.cpp			Functions for doubly linked list from chapter
	circle.cpp			Functions for the circularly linked list from
						the chapter
	ArrayLL.h				Array of records specification
	ArrayLL.cpp			Array of records implementation
	Copy.cpp				Three stack copy functions

SortedType.h					range-based for loop
SortedTypeIterator.h	range-based for loop
