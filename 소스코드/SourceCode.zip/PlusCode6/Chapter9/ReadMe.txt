Files

PQ
	PQType.h		Specification and implementation of PQType class
				template
	PQDr.cpp		Test driver for PQType
	Heap.h		Specification and implementation of HeapType class
				template
	PQ.in		Input to the test driver

HeapSort.h 		heap sort
