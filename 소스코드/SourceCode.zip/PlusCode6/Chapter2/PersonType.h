#include <string>
class PersonType
{
public:
  void Initialize(string, DateType);
  string NameIs();
  DateType BirthdateIs();
private;
  string name;
  DateType birthdate;
};

